package com.alte.allconvertor

import android.util.Base64
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.util.zip.ZipInputStream

class Gh(private val token: String, private val workflow: String) {
    private var owner = ""
    private val repo = "alte-builder"
    private val api = "https://api.github.com"

    private fun call(method: String, url: String, body: String? = null): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 30000; c.readTimeout = 180000
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        if (body != null) { c.doOutput = true; c.outputStream.use { it.write(body.toByteArray()) } }
        val code = c.responseCode
        val txt = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText().orEmpty()
        return code to txt
    }

    private fun put(path: String, bytes: ByteArray) {
        val j = JSONObject().put("message", "alte").put("content", Base64.encodeToString(bytes, Base64.NO_WRAP))
        val (c, t) = call("PUT", "$api/repos/$owner/$repo/contents/$path", j.toString())
        if (c !in 200..201) error("GitHub $c: ${t.take(160)}")
    }

    fun setup() {
        val (c, t) = call("GET", "$api/user")
        if (c != 200) error("Неверный токен ($c)")
        owner = JSONObject(t).getString("login")
        if (call("GET", "$api/repos/$owner/$repo").first == 404) {
            val (cc, ct) = call("POST", "$api/user/repos", """{"name":"$repo","private":true,"auto_init":true}""")
            if (cc != 201) error("Не создался репозиторий: ${ct.take(160)}")
            Thread.sleep(3000)
        }
        val path = ".github/workflows/build.yml"
        if (call("GET", "$api/repos/$owner/$repo/contents/$path").first != 200) put(path, workflow.toByteArray())
    }

    fun build(zip: ByteArray, out: File, step: (Int) -> Unit) {
        val job = UUID.randomUUID().toString().take(8)
        step(1)
        put("jobs/$job.zip", zip)
        var ok = false
        repeat(8) {
            if (!ok) {
                val r = call("POST", "$api/repos/$owner/$repo/actions/workflows/build.yml/dispatches",
                    """{"ref":"main","inputs":{"job":"$job"}}""")
                if (r.first == 204) ok = true else Thread.sleep(4000)
            }
        }
        if (!ok) error("Не удалось запустить сборку (нужны права repo + workflow у токена)")
        step(2)
        var runId = 0L
        val t0 = System.currentTimeMillis()
        while (runId == 0L) {
            if (System.currentTimeMillis() - t0 > 40 * 60 * 1000) error("Таймаут сборки")
            Thread.sleep(6000)
            val (c, t) = call("GET", "$api/repos/$owner/$repo/actions/runs?event=workflow_dispatch&per_page=15")
            if (c != 200) continue
            val runs = JSONObject(t).getJSONArray("workflow_runs")
            for (i in 0 until runs.length()) {
                val r = runs.getJSONObject(i)
                if (r.optString("display_title") == "build $job" && r.getString("status") == "completed") {
                    if (r.getString("conclusion") != "success") error("Сборка упала. Лог: ${r.getString("html_url")}")
                    runId = r.getLong("id")
                }
            }
        }
        step(3)
        val (_, at) = call("GET", "$api/repos/$owner/$repo/actions/runs/$runId/artifacts")
        val arts = JSONObject(at).getJSONArray("artifacts")
        if (arts.length() == 0) error("APK не найден в результатах сборки")
        val id = arts.getJSONObject(0).getLong("id")
        val conn = URL("$api/repos/$owner/$repo/actions/artifacts/$id/zip").openConnection() as HttpURLConnection
        conn.instanceFollowRedirects = false
        conn.setRequestProperty("Authorization", "Bearer $token")
        val loc = conn.getHeaderField("Location") ?: error("Нет ссылки на скачивание")
        ZipInputStream(URL(loc).openStream()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (e.name.endsWith(".apk")) { out.outputStream().use { z.copyTo(it) }; return }
                e = z.nextEntry
            }
        }
        error("APK не найден в архиве")
    }
}
