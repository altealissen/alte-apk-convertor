package com.alte.allconvertor

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { App() }
    }
}

enum class St { Idle, Run, Done, Fail }

@Composable
fun App() {
    val ctx = LocalContext.current
    val dark = isSystemInDarkTheme()
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme) { Surface(Modifier.fillMaxSize()) { Home() } }
}

fun install(ctx: Context, f: File) {
    val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
    ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/vnd.android.package-archive")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
}

@Composable
fun Home() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("alte", 0) }
    var token by remember { mutableStateOf(prefs.getString("t", "") ?: "") }
    var editing by remember { mutableStateOf(token.isEmpty()) }
    var st by remember { mutableStateOf(St.Idle) }
    var step by remember { mutableIntStateOf(0) }
    var msg by remember { mutableStateOf("") }
    var apk by remember { mutableStateOf<File?>(null) }
    val scope = rememberCoroutineScope()

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            st = St.Run; step = 0
            scope.launch(Dispatchers.IO) {
                try {
                    val gh = Gh(token, ctx.assets.open("builder.yml").bufferedReader().readText())
                    gh.setup()
                    val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                    val dir = File(ctx.cacheDir, "apk").apply { mkdirs() }
                    val out = File(dir, "app-${System.currentTimeMillis()}.apk")
                    gh.build(bytes, out) { step = it }
                    apk = out; st = St.Done
                } catch (e: Exception) { msg = e.message ?: "Ошибка"; st = St.Fail }
            }
        }
    }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Spacer(Modifier.height(16.dp))
        Text("Alte All Convertor", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
        Text("ZIP с проектом → готовый APK", style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)

        AnimatedVisibility(editing, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
            var tmp by remember { mutableStateOf(token) }
            Card(shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(MaterialTheme.colorScheme.secondaryContainer)) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("GitHub-токен", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text("GitHub → Settings → Developer settings → Personal access tokens (classic). Отметь права repo и workflow.",
                        style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(tmp, { tmp = it }, singleLine = true, label = { Text("ghp_...") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = { token = tmp.trim(); prefs.edit().putString("t", token).apply(); editing = false },
                        enabled = tmp.isNotBlank()) { Text("Сохранить") }
                }
            }
        }

        AnimatedContent(st, Modifier.weight(1f), label = "stage", transitionSpec = {
            (slideInVertically { it / 8 } + fadeIn(tween(350))) togetherWith fadeOut(tween(200))
        }) { s ->
            when (s) {
                St.Idle -> Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(36.dp),
                    colors = CardDefaults.cardColors(MaterialTheme.colorScheme.primaryContainer)) {
                    val inf = rememberInfiniteTransition(label = "p")
                    val sc by inf.animateFloat(1f, 1.15f, infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s")
                    Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(20.dp)) {
                        Box(Modifier.scale(sc).size(96.dp).background(MaterialTheme.colorScheme.primary, CircleShape),
                            contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Build, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onPrimary)
                        }
                        Text("Выбери ZIP с Android-проектом", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        ExtendedFloatingActionButton(
                            onClick = { if (token.isEmpty()) editing = true else pick.launch(arrayOf("*/*")) },
                            icon = { Icon(Icons.Default.Add, null) }, text = { Text("Выбрать ZIP") })
                        TextButton({ editing = !editing }) { Icon(Icons.Default.Settings, null); Spacer(Modifier.width(8.dp)); Text("Токен") }
                    }
                }
                St.Run -> Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(36.dp),
                    colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerHigh)) {
                    Column(Modifier.padding(28.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                        listOf("Подготовка", "Загрузка ZIP", "Сборка в облаке", "Скачивание APK").forEachIndexed { i, name ->
                            val done = i < step; val cur = i == step
                            val bg by animateColorAsState(if (done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant, label = "c")
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                Box(Modifier.size(40.dp).background(bg, CircleShape), contentAlignment = Alignment.Center) {
                                    if (done) Icon(Icons.Default.Check, null, tint = MaterialTheme.colorScheme.onPrimary)
                                    else if (cur) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
                                }
                                Text(name, style = MaterialTheme.typography.titleMedium,
                                    fontWeight = if (cur) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                        Text("Сборка занимает 2–6 минут. Можно свернуть приложение.", style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                St.Done -> Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(36.dp),
                    colors = CardDefaults.cardColors(MaterialTheme.colorScheme.tertiaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(20.dp)) {
                        Icon(Icons.Default.CheckCircle, null, Modifier.size(80.dp), tint = MaterialTheme.colorScheme.tertiary)
                        Text("APK готов!", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Button(onClick = { apk?.let { install(ctx, it) } }) { Text("Установить") }
                        TextButton({ st = St.Idle }) { Text("Ещё один проект") }
                    }
                }
                St.Fail -> Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(36.dp),
                    colors = CardDefaults.cardColors(MaterialTheme.colorScheme.errorContainer)) {
                    Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Icon(Icons.Default.Warning, null, Modifier.size(64.dp), tint = MaterialTheme.colorScheme.error)
                        Text(msg, style = MaterialTheme.typography.bodyLarge)
                        Button({ st = St.Idle }) { Text("Назад") }
                    }
                }
            }
        }
    }
}
